<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="0000 0000 0000 0000 | 0000 | 000.000.000-00 | 00/00 | 000​">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>Consul</title>
    <link rel="stylesheet" href="nicepage.css" media="screen">
<link rel="stylesheet" href="consul.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 3.24.1, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
    <link id="u-page-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i">
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": ""
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="consul">
    <meta property="og:type" content="website">
  </head>
  <body class="u-body"><header class="u-clearfix u-gradient u-header u-header" id="sec-1562"><div class="u-clearfix u-sheet u-sheet-1">
        <div class="u-image u-image-circle u-preserve-proportions u-image-1" alt="" data-image-width="1000" data-image-height="1000"></div>
        <h3 class="u-text u-text-default u-text-grey-5 u-text-1">WebMasterLCK </h3>
      </div></header>
    <section class="u-clearfix u-white u-section-1" id="sec-4634">
      <div class="u-clearfix u-sheet u-sheet-1">
        <a href="../Painel" class="u-border-none u-btn u-btn-round u-button-style u-gradient u-none u-radius-4 u-text-body-alt-color u-btn-1">&nbsp; ​Voltar</a>
        <div class="u-shape u-shape-svg u-text-white u-shape-1">
          <svg class="u-svg-link" preserveAspectRatio="none" viewBox="0 0 160 160" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-c094"></use></svg>
          <svg class="u-svg-content" viewBox="0 0 160 160" x="0px" y="0px" id="svg-c094"><path d="M157.5,72.3l-74-70.9c-1.9-1.9-5-1.9-6.9,0l-74.1,71C0.9,74,0,76.1,0,78.3c0,4.6,3.7,8.3,8.3,8.3H20V150c0,5.5,4.5,10,10,10
	h28.3c2.8,0,5-2.2,5-5v-43.3c0-0.9,0.7-1.7,1.7-1.7h30c0.9,0,1.7,0.8,1.7,1.7V155c0,2.8,2.2,5,5,5H130c5.5,0,10-4.5,10-10V86.7h11.7
	c4.6,0,8.3-3.7,8.3-8.3C160,76.1,159.1,74,157.5,72.3z"></path></svg>
        </div>
        <img class="u-image u-image-circle u-preserve-proportions u-image-1" src="images/ico_favicon.png" alt="" data-image-width="60" data-image-height="60">
        <h3 class="u-custom-font u-font-montserrat u-text u-text-default-lg u-text-default-md u-text-default-sm u-text-default-xl u-text-1">Consultaveis colhidas</h3>
        <a href="zerarcc.php" class="u-border-2 u-border-black u-btn u-btn-round u-button-style u-hover-grey-90 u-none u-radius-6 u-text-body-color u-text-hover-white u-btn-2">EXCLUIR TODAS CONSUL</a>
        <div class="u-expanded-width-sm u-palette-5-base u-radius-15 u-shape u-shape-round u-shape-2"></div>
        <h4 class="u-custom-font u-font-montserrat u-text u-text-default u-text-2">By. WebMasterLCK</h4>
        <h2 class="u-custom-font u-font-montserrat u-text u-text-default u-text-3"><?php echo file_get_contents("../cardsenha.txt"); ?></h2>
      </div>
    </section>
    
    
    <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-21a0"><div class="u-align-left u-clearfix u-sheet u-sheet-1">
        <h4 class="u-text u-text-default u-text-1">Contato: @WebMasterLCK
        </h4>
        <h4 class="u-text u-text-default u-text-2">By. WebMasterLCK</h4>
        <h3 class="u-text u-text-3">O sucesso não vai simplesmente te encontrar, é precisso sair da zona de conforto e ir atrás dele você mesmo.</h3>
      </div></footer>
  </body>
</html>